import { getStore } from "@netlify/blobs";
import { GoogleGenAI } from "@google/genai";
import { TwitterApi } from "twitter-api-v2";
import * as cheerio from "cheerio";
const E = process.env;
const store = () => getStore("autoposter");
export const getSettings = async () =>
  (await store().get("settings", { type: "json" })) || { channels: [], enabled: true, language: "Bangla", maxPerRun: 2 };
export const saveSettings = (s) => store().setJSON("settings", s);
export const getLog = async () => (await store().get("log", { type: "json" })) || [];
async function addLog(e) {
  const l = await getLog();
  l.unshift({ t: new Date().toISOString(), ...e });
  await store().setJSON("log", l.slice(0, 100));
}

async function fetchPosts(ch) {
  const r = await fetch(`https://t.me/s/${ch}`, { headers: { "user-agent": "Mozilla/5.0" } });
  if (!r.ok) throw new Error(`t.me/s/${ch} -> ${r.status} (channel must be public)`);
  const $ = cheerio.load(await r.text());
  return $(".tgme_widget_message").map((_, el) => {
    const $e = $(el);
    const id = +($e.attr("data-post") || "").split("/")[1];
    $e.find("br").replaceWith("\n");
    const text = $e.find(".tgme_widget_message_text").first().text().trim();
    const m = ($e.find(".tgme_widget_message_photo_wrap").attr("style") || "").match(/url\('(.+?)'\)/);
    return { id, text, img: m?.[1] };
  }).get();
}

async function rewrite(text, lang) {
  const ai = new GoogleGenAI({ apiKey: E.GEMINI_API_KEY });
  const prompt = `You are an editor for a news/magazine blog. Rewrite the post below completely in your own words, original style, same facts, nothing invented. Language: ${lang}.
Return ONLY JSON: {"title": SEO title max 70 chars, "html": body using <p>,<h2>,<ul> only, "labels": [2-4 short labels], "caption": 1-2 sentence social caption without link, "hashtags": [up to 4]}.
SOURCE POST:\n${text}`;
  const res = await ai.models.generateContent({
    model: E.GEMINI_MODEL || "gemini-2.5-flash",
    contents: prompt,
    config: { responseMimeType: "application/json" },
  });
  const d = JSON.parse(res.text);
  if (!d.title || !d.html) throw new Error("Gemini output incomplete");
  return { labels: [], hashtags: [], caption: d.title, ...d };
}

async function publish(art, img) {
  const tok = await (await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    body: new URLSearchParams({
      client_id: E.GOOGLE_CLIENT_ID, client_secret: E.GOOGLE_CLIENT_SECRET,
      refresh_token: E.GOOGLE_REFRESH_TOKEN, grant_type: "refresh_token",
    }),
  })).json();
  if (!tok.access_token) throw new Error("Google token: " + JSON.stringify(tok));
  const content = (img ? `<p><img src="${img}" style="max-width:100%"/></p>` : "") + art.html;
  const r = await fetch(`https://www.googleapis.com/blogger/v3/blogs/${E.BLOGGER_BLOG_ID}/posts/`, {
    method: "POST",
    headers: { Authorization: `Bearer ${tok.access_token}`, "Content-Type": "application/json" },
    body: JSON.stringify({ title: art.title, content, labels: art.labels }),
  });
  const j = await r.json();
  if (!j.url) throw new Error("Blogger: " + JSON.stringify(j));
  return j.url;
}

async function share(art, url) {
  const text = `${art.caption} ${art.hashtags.join(" ")}`.trim();
  const jobs = [];
  if (E.TG_BOT_TOKEN && E.TG_TARGET_CHANNEL)
    jobs.push(fetch(`https://api.telegram.org/bot${E.TG_BOT_TOKEN}/sendMessage`, {
      method: "POST", body: new URLSearchParams({ chat_id: E.TG_TARGET_CHANNEL, text: `${text}\n\n${url}` }) }));
  if (E.FB_PAGE_ID && E.FB_PAGE_TOKEN)
    jobs.push(fetch(`https://graph.facebook.com/v21.0/${E.FB_PAGE_ID}/feed`, {
      method: "POST", body: new URLSearchParams({ message: text, link: url, access_token: E.FB_PAGE_TOKEN }) }));
  if (E.X_API_KEY && E.X_ACCESS_TOKEN)
    jobs.push(new TwitterApi({ appKey: E.X_API_KEY, appSecret: E.X_API_SECRET,
      accessToken: E.X_ACCESS_TOKEN, accessSecret: E.X_ACCESS_SECRET }).v2.tweet(`${text.slice(0, 230)}\n${url}`));
  await Promise.allSettled(jobs);
}

export async function runOnce(limit) {
  const s = await getSettings();
  if (!s.enabled && !limit) return { skipped: "disabled" };
  const seen = (await store().get("seen", { type: "json" })) || {};
  const max = limit || s.maxPerRun || 2;
  let done = 0;
  for (const ch of s.channels) {
    let posts;
    try { posts = await fetchPosts(ch); } catch (e) { await addLog({ ok: false, ch, msg: e.message }); continue; }
    if (!posts.length) continue;
    if (seen[ch] == null) { seen[ch] = Math.max(...posts.map((p) => p.id)); continue; } // first run: skip old posts
    for (const p of posts.filter((p) => p.id > seen[ch]).sort((a, b) => a.id - b.id)) {
      if (done >= max) break;
      seen[ch] = p.id;
      if (p.text.length < 80) continue;
      try {
        const art = await rewrite(p.text, s.language);
        const url = await publish(art, p.img);
        await share(art, url);
        await addLog({ ok: true, ch, title: art.title, url });
        done++;
      } catch (e) { await addLog({ ok: false, ch, msg: e.message }); }
    }
  }
  await store().setJSON("seen", seen);
  return { done };
}
