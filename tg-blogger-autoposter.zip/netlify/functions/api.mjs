import { getSettings, saveSettings, getLog, runOnce } from "./lib.mjs";
const json = (d, s = 200) => new Response(JSON.stringify(d), { status: s, headers: { "content-type": "application/json" } });
export default async (req) => {
  if (!process.env.ADMIN_PASSWORD || req.headers.get("x-admin-password") !== process.env.ADMIN_PASSWORD)
    return json({ error: "unauthorized" }, 401);
  if (req.method === "GET") return json({ settings: await getSettings(), log: await getLog() });
  const b = await req.json();
  if (b.action === "save") {
    const channels = (b.channels || []).map((c) => c.replace(/^.*t\.me\/(s\/)?/, "").replace("@", "").trim()).filter(Boolean);
    await saveSettings({ channels, enabled: !!b.enabled, language: b.language || "Bangla", maxPerRun: 2 });
    return json({ ok: true });
  }
  if (b.action === "run") return json(await runOnce(1));
  return json({ error: "bad action" }, 400);
};
export const config = { path: "/api" };
