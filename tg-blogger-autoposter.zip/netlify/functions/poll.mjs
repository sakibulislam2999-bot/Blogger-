import { runOnce } from "./lib.mjs";
export default async () => { await runOnce(); };
export const config = { schedule: "*/15 * * * *" };
